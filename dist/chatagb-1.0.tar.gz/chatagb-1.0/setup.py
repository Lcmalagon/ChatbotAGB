from setuptools import setup, find_packages


setup(
    name='chatagb',
    version='1.0',
    description='Chatbot that can answer questions from alumni CSV',
    author='lcmalagon',
    author_email='lcm12@stmarys-ca.edu',
    packages=find_packages(),
    install_requires=[
        'langchain>=1.0',  # Example version specification
        'openai>=1.0',
        'chromadb>=1.0',
        'kaleido>=1.0',
        'python-multipart>=1.0',
        'tiktoken>=1.0',
        'sqlalchemy>=1.4',
        'streamlit>=1.0',
        'pandas>=1.2',
        'gpt4all>=1.0',
        # Include any other specific libraries you need for your project
    ],
)

